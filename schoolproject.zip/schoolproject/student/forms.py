from django import forms
from .models import *

class studentregform(forms.ModelForm):
	class Meta:
		model=studentdetails
		fields="__all__"

	def __init__(self,*args,**kwargs):
		super(studentregform, self).__init__(*args,**kwargs)
		self.fields['first_name'].widget.attrs['class']='form-control'
		self.fields['last_name'].widget.attrs['class']='form-control'
		self.fields['guardian_full_name'].widget.attrs['class']='form-control'
		self.fields['tel'].widget.attrs['class']='form-control'
		self.fields['residence'].widget.attrs['class']='form-control'
from django.db import models

# Create your models here.

class studentdetails(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    guardian_full_name =models.CharField(max_length=50)
    tel=models.CharField(max_length=50)
    residence =models.CharField(max_length=50)




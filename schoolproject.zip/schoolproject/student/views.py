from django.shortcuts import render, redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from .forms import *
from .models import *

# Create your views here.

def homeview(request):
	# return HttpResponse("Welcome to our school landing page")
	x=5
	y=6
	z=x*y
	return render(request,'index.html')



def successview(request):
	
	return render(request,'success.html')

def studentsview(request):
	mystudents=studentdetails.objects.all
	context={'ms':mystudents}
	return render(request,'mystudents.html',context)

def updateview(request,id):
	students=studentdetails.objects.get(id=id)
	return render(request,'updatestudents.html',{'mystudents':students})

def updatefinishedview(request,id):
	firstname=request.POST.get('fname')
	lastname=request.POST.get('lname')
	gname=request.POST.get('gname')
	telephone=request.POST.get('tno')
	res=request.POST.get('residence')

	student=studentdetails.objects.get(id=id)
	student.first_name=firstname
	student.last_name=lastname
	student.guardian_full_name=gname
	student.tel=telephone
	student.residence=res
	student.save()
	return HttpResponseRedirect(reverse('home'))


def deleteview(request,id):
	student=studentdetails.objects.get(id=id)
	student.delete()
	return HttpResponseRedirect(reverse('viewstudents'))


def studentregview(request):
	msg=''
	if request.method=='POST':
		form=studentregform(request.POST)
		if form.is_valid():
			form.save()
			return redirect('success')
		else:

			msg+="Failed to process your request, form is invalid"
	else:
		form=studentregform()
	context={'myform':form,'msg':msg}

	return render(request,'studentreg.html',context)

	